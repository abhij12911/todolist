class task {
  constructor(index = 0, description, isCompeleted = false) {
    this.index = index;
    this.description = description;
    this.isCompeleted = isCompeleted;
  }
}
export default task;